## Newest update
📌 **v0.5.5 - July 16th, 2023**

- **Bug Fix:** The XP gained for mining rocks/deposits, fractured or not, should be 100% accurate now.

Github: https://github.com/DeepWolf413/Cozyheim-Mods
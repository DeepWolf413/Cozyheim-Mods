## Newest update
📌 **v0.5.4 - July 16th, 2023**

- **Addition:** Added the ability to change the base value of each skill. (Info about how to do it is shown when you hover over a skill setting).
- **Addition:** Added compatibility with "Jewelcrafting by Smoothbrain". You can change the xp rewards in "config/LevelingSystem/MiningXP/Jewelcrafting Mining.json". By default they are set to give around 5 xp.
- **Bug Fix:** Fixed fractured rocks not giving experience.
- **Bug Fix:** Fixed some normal rocks not giving experience.
- **Bug Fix:** Fixed an error caused by disabling a skill.

Github: https://github.com/DeepWolf413/Cozyheim-Mods
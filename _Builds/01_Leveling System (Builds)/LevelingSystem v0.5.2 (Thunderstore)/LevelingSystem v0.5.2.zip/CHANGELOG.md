## Newest update
📌 **v0.5.2 - July 5th, 2023**

- **Bug Fix:** Fixed errors caused by changes to the game API.
- **Bug Fix:** Fixed config settings not showing up in the Configuration Manager.
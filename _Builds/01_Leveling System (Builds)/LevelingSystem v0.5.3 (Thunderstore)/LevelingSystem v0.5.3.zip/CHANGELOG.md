## Newest update
📌 **v0.5.3 - July 10th, 2023**

- **Change:** Updated BepInEx dependency string.
- **Change:** Updated Cozyheim_CoreAPI.dll.
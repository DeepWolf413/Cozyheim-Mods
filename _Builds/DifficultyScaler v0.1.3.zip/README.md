## Thank you for using this mod.  
Support the author by donating some mead for Thrakal here:
https://www.buymeacoffee.com/Thrakal |
--

&nbsp;
## Info
This mod requires the <b>"Cozyheim_CoreAPI.dll"</b> to be installed.
- This file is included in all mods you download from Cozyheim
- It is used to make the Cozyheim mods "speak" with each other
- If you don't have this installed, your mods from Cozyheim will not be loaded  
&nbsp;

## Bug reporting and feedback
If you have any feedback or issues you need fixed, go to:
[NEXUS MODS](https://www.nexusmods.com/valheim/users/169446733?tab=user+files)

Click on the mod you need support for:
- Report Bug
- Post
- Share image

Or join the [Cozyheim Discord Server](https://discord.gg/KjuQHJqqXe)

&nbsp;
--

| Learn more about the author and his mods at www.cozyheim.dk |
--

*Thunderstore is NOT the main page for uploading mods. Make sure to stay updated at nexusmods.com*
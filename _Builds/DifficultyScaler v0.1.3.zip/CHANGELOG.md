## Full Changelog
* The full changelog can be found on Nexus ([Changelog](https://www.nexusmods.com/valheim/mods/2341))

## Newest update
📌 **v0.1.2 - April 29th, 2023**

- **Important!** - If you also use the Experience & Leveling System mod, then you must update that mod as well, otherwise you will encounter issues with the amount of XP gained.
- **New feature:** Added the option to adjust the scaling based on how many stars the monsters have. This setting will overwrite the vanilla scaling.
- **Change:** Changed the mathematic equation for how the difficulty scaling is calculated. The scaling values now **ADDS** together instead of MULTIPLIES.
    - **Example before:** (overall health +200% * night +50% * Mistlands +100% = 3 * 1,5 * 2 = 9x health)
    - **Example new:** (overall health +200% * night +50% * Mistlands +100% = 2 + 0,5 + 1 = 3.5x health)
- **Config:** Due to the changes in the equation, some of the default values in the config file has changed. Also the values has been streamlined to be more clear on how the scaling functions.
- **Bug Fix:** Fixed null reference error when monsters get hit by a “non-attacker” object, such as bonfire etc.
- **Core API:** Added changes to the Core API to implement the scaling for stars.

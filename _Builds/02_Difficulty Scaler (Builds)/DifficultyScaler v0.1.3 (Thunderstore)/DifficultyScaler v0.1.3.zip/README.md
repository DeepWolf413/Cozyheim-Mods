## Info
Hi! I decided to update this mod from the original creator, and fix it so it works with the latest Valheim version.
If you have any issues check the "Bug reporting..." section below.

## Bug reporting and feedback
If you have any feedback or issues you need fixed, you can join the original creator's Discord server, or DM me on Discord: **deepwolf**

[Cozyheim Discord Server](https://discord.gg/KjuQHJqqXe)

## Credits
The original mod was made by **Thrakal** (aka Cozyheim).
This version of the mod is fixed/updated by DeepWolf413 (me).

&nbsp;
--

| Learn more about the original author and his mods at www.cozyheim.dk |
--
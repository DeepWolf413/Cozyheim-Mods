## Newest update
📌 **v0.1.4 - July 10th, 2023**

- **Change:** Updated BepInEx dependency string.
- **Change:** Updated Cozyheim_CoreAPI.dll.
- **Bug Fix:** Fixed an issue with mobs not scaling when using "Spawner_Tweaks by AzuRe". It seems to work fine now after a few quick tests.
## Full Changelog
* The full changelog can be found on Nexus ([Changelog](https://www.nexusmods.com/valheim/mods/2282))

## Newest update
📌 **v0.5.0 - April 29th, 2023**

- **New Feature:** Supports XP scaling based on monster star difficulty scaling from Difficulty Scaler
- **Changes:** Adjusted the integration with Difficulty Scaler, to support correct XP scaling based on the new equation implemented in Difficulty Scaler.
- **New Skills:** Added 8 new skills
    - *Resistance Slash*
    - *Resistance Pierce*
    - *Resistance Blunt*
    - *Resistance Fire*
    - *Resistance Frost*
    - *Resistance Lightning*
    - *Resistance Poison*
    - *Resistance Spirit*
- **Bug Fix:** Fixed null reference error when using “Rune of Blasting” from the Rune Magic mod
- **Bug Fix:** Fixed issues with Stamina Regen skill not working. It now increases your regen as expected.